import React, { useCallback, useRef, useState } from "react";
import { Loader2, Plug, Wallet, Send, Server, Database, Coins, Gauge, ShieldCheck } from "lucide-react";
import { ethers } from "ethers"; // v6
import { Connection, PublicKey, LAMPORTS_PER_SOL } from "@solana/web3.js";

class RollingLatency { constructor(cap=60){this.cap=cap; this.a=[];} a:number[]; cap:number; push(ms:number){this.a.push(ms); if(this.a.length>this.cap) this.a.shift(); } p(p:number){ if(!this.a.length) return 0; const b=[...this.a].sort((x,y)=>x-y); const i=Math.min(b.length-1, Math.floor((p/100)*b.length)); return b[i]; } }
async function withTimeout(p, ms=6000){ return await Promise.race([p, new Promise((_,rej)=>setTimeout(()=>rej(new Error("Timeout "+ms+"ms")), ms))]); }

const EXPECTED_EVM_CHAIN_ID = Number((import.meta).env?.VITE_EXPECTED_EVM_CHAIN_ID ?? 16979);
const DEFAULT_EVM_RPC = (import.meta).env?.VITE_EVM_RPC ?? "";
const DEFAULT_SOL_RPC = (import.meta).env?.VITE_SOL_RPC ?? "";

export default function App(){
  const [evmRpc, setEvmRpc] = useState(DEFAULT_EVM_RPC);
  const [solRpc, setSolRpc] = useState(DEFAULT_SOL_RPC);
  const [appliedEvmRpc, setAppliedEvmRpc] = useState(DEFAULT_EVM_RPC);
  const [appliedSolRpc, setAppliedSolRpc] = useState(DEFAULT_SOL_RPC);

  const [ethProvider, setEthProvider] = useState(null);
  const [ethWallet, setEthWallet] = useState(undefined);
  const [ethBalance, setEthBalance] = useState("-");
  const [chainId, setChainId] = useState(undefined);
  const [gasGwei, setGasGwei] = useState("-");
  const [evmBusy, setEvmBusy] = useState(false);
  const [evmStatus, setEvmStatus] = useState("");
  const evmLatency = useRef(new RollingLatency());

  const [solConn, setSolConn] = useState(null);
  const [solPubkey, setSolPubkey] = useState(null);
  const [solBalance, setSolBalance] = useState("-");
  const [solBusy, setSolBusy] = useState(false);
  const [solStatus, setSolStatus] = useState("");
  const solLatency = useRef(new RollingLatency());

  const applyRpcs = useCallback(()=>{
    setEvmStatus(""); setSolStatus("");
    if(evmRpc){ try{ setEthProvider(new ethers.JsonRpcProvider(evmRpc)); setAppliedEvmRpc(evmRpc);}catch(e){ setEvmStatus("EVM provider init failed: "+e.message);} }
    else { setEthProvider(null); setAppliedEvmRpc(""); }
    if(solRpc){ try{ setSolConn(new Connection(solRpc, { commitment: "confirmed" })); setAppliedSolRpc(solRpc);}catch(e){ setSolStatus("Solana conn init failed: "+e.message);} }
    else { setSolConn(null); setAppliedSolRpc(""); }
  },[evmRpc,solRpc]);

  const enforceNetwork = useCallback(async()=>{
    const { ethereum } = window; if(!ethereum) return;
    const hex = "0x"+EXPECTED_EVM_CHAIN_ID.toString(16);
    try{ await ethereum.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: hex }] }); }
    catch(err){ if(err && err.code===4902){ await ethereum.request({ method:'wallet_addEthereumChain', params:[{ chainId: hex, chainName:'BSSC', nativeCurrency:{ name:'BNB', symbol:'BNB', decimals:18 }, rpcUrls:[appliedEvmRpc||evmRpc].filter(Boolean), blockExplorerUrls:[] }] }); } else { throw err; } }
  },[evmRpc, appliedEvmRpc]);

  const connectMetamask = useCallback(async()=>{
    setEvmBusy(true);
    try{
      const { ethereum } = window; if(!ethereum) throw new Error('MetaMask not found');
      await enforceNetwork();
      const accounts = await ethereum.request({ method:'eth_requestAccounts' });
      const addr = accounts?.[0]; setEthWallet(addr);
      if(!ethProvider) throw new Error('No EVM RPC set (Apply)');
      const t0 = performance.now();
      const [cidHex, bal, gas] = await Promise.all([
        withTimeout(ethProvider.send('eth_chainId', [])),
        withTimeout(ethProvider.getBalance(addr)),
        withTimeout(ethProvider.getGasPrice())
      ]);
      evmLatency.current.push(performance.now()-t0);
      const cid = parseInt(cidHex,16); setChainId(cid);
      if(cid!==EXPECTED_EVM_CHAIN_ID) throw new Error('Unexpected chainId '+cid+' (expected '+EXPECTED_EVM_CHAIN_ID+')');
      setEthBalance(ethers.formatEther(bal));
      setGasGwei(Number(ethers.formatUnits(gas,'gwei')).toFixed(3));
      setEvmStatus('Connected. chainId='+cid);
    }catch(e){ setEvmStatus(e?.message||String(e)); }
    finally{ setEvmBusy(false); }
  },[ethProvider, enforceNetwork]);

  const evmProbe = useCallback(async()=>{
    setEvmBusy(true);
    try{
      if(!ethProvider) throw new Error('No EVM RPC set');
      const t0 = performance.now();
      const [cidHex, block] = await Promise.all([
        withTimeout(ethProvider.send('eth_chainId', [])),
        withTimeout(ethProvider.getBlockNumber())
      ]);
      evmLatency.current.push(performance.now()-t0);
      setEvmStatus('OK chainId='+parseInt(cidHex,16)+' block='+block+' | p50 '+evmLatency.current.p(50).toFixed(0)+'ms p95 '+evmLatency.current.p(95).toFixed(0)+'ms');
    }catch(e){ setEvmStatus(e?.message||String(e)); }
    finally{ setEvmBusy(false); }
  },[ethProvider]);

  const sendTinyEthTx = useCallback(async()=>{
    setEvmBusy(true);
    try{
      const { ethereum } = window; if(!ethereum) throw new Error('MetaMask not found');
      if(!ethWallet) throw new Error('Connect MetaMask first');
      const browser = new ethers.BrowserProvider(ethereum);
      const signer = await browser.getSigner();
      const tx = await signer.sendTransaction({ to: ethWallet, value: ethers.parseEther('0.0000001') });
      const rcpt = await withTimeout(tx.wait());
      setEvmStatus('TX success hash='+(rcpt?.hash||tx.hash));
      if(ethProvider){ const bal = await withTimeout(ethProvider.getBalance(ethWallet)); setEthBalance(ethers.formatEther(bal)); }
    }catch(e){ setEvmStatus(e?.message||String(e)); }
    finally{ setEvmBusy(false); }
  },[ethWallet, ethProvider]);

  const connectPhantom = useCallback(async()=>{
    setSolBusy(true);
    try{
      const provider = window.solana; if(!provider||!provider.isPhantom) throw new Error('Phantom not found');
      const resp = await provider.connect();
      const key = new PublicKey(resp.publicKey.toString()); setSolPubkey(key);
      if(!solConn) throw new Error('No Solana RPC set (Apply)');
      const t0 = performance.now();
      const [health, slot] = await Promise.all([
        withTimeout(solConn.getHealth()),
        withTimeout(solConn.getSlot())
      ]);
      solLatency.current.push(performance.now()-t0);
      const bal = await withTimeout(solConn.getBalance(key));
      setSolBalance((bal/LAMPORTS_PER_SOL).toFixed(6));
      setSolStatus('Health '+health+' slot '+slot+' | p50 '+solLatency.current.p(50).toFixed(0)+'ms p95 '+solLatency.current.p(95).toFixed(0)+'ms');
    }catch(e){ setSolStatus(e?.message||String(e)); }
    finally{ setSolBusy(false); }
  },[solConn]);

  const solAirdrop = useCallback(async()=>{
    setSolBusy(true);
    try{
      if(!solConn) throw new Error('No Solana RPC set');
      if(!solPubkey) throw new Error('Connect Phantom first');
      const sig = await withTimeout(solConn.requestAirdrop(solPubkey, 0.01*LAMPORTS_PER_SOL));
      await withTimeout(solConn.confirmTransaction(sig, 'confirmed'));
      const bal = await withTimeout(solConn.getBalance(solPubkey));
      setSolBalance((bal/LAMPORTS_PER_SOL).toFixed(6));
      setSolStatus('Airdrop success sig='+sig);
    }catch(e){ setSolStatus(e?.message||String(e)); }
    finally{ setSolBusy(false); }
  },[solConn, solPubkey]);

  return (
    <div className="min-h-screen w-full bg-gray-50 py-10">
      <div className="max-w-6xl mx-auto px-4">
        <h1 className="text-3xl font-semibold mb-2">BSSC Dapp — Enterprise Starter</h1>
        <p className="text-gray-600 mb-6">Plug in your RPCs. Expected EVM chainId <code>{EXPECTED_EVM_CHAIN_ID}</code>.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-white rounded-2xl shadow p-5">
            <div className="flex items-center gap-2 mb-3"><Server className="w-5 h-5"/><h2 className="text-xl font-medium">RPC Settings</h2></div>
            <label className="block text-sm text-gray-600 mb-1">EVM JSON-RPC URL</label>
            <input className="w-full border rounded-lg px-3 py-2 mb-3" placeholder="http://localhost:8545" value={evmRpc} onChange={e=>setEvmRpc(e.target.value)} />
            <label className="block text-sm text-gray-600 mb-1">Solana JSON-RPC URL</label>
            <input className="w-full border rounded-lg px-3 py-2 mb-4" placeholder="http://localhost:8899" value={solRpc} onChange={e=>setSolRpc(e.target.value)} />
            <button onClick={applyRpcs} className="px-4 py-2 rounded-xl bg-black text-white hover:opacity-90">Apply</button>
            <div className="text-xs text-gray-500 mt-2">Applied EVM: {appliedEvmRpc || '-'}<br/>Applied Solana: {appliedSolRpc || '-'}</div>
          </div>

          <div className="bg-white rounded-2xl shadow p-5">
            <div className="flex items-center gap-2 mb-3"><Database className="w-5 h-5"/><h2 className="text-xl font-medium">Node Health</h2></div>
            <div className="flex flex-col gap-3">
              <button onClick={evmProbe} disabled={!ethProvider || evmBusy} className="px-4 py-2 rounded-xl border flex items-center gap-2 justify-center disabled:opacity-50">
                {evmBusy ? <Loader2 className="w-4 h-4 animate-spin"/> : <Plug className="w-4 h-4"/> } Check EVM RPC
              </button>
              <button onClick={connectMetamask} disabled={!ethProvider || evmBusy} className="px-4 py-2 rounded-xl border flex items-center gap-2 justify-center disabled:opacity-50">
                {evmBusy ? <Loader2 className="w-4 h-4 animate-spin"/> : <Wallet className="w-4 h-4"/>} Connect MetaMask
              </button>
              <button onClick={sendTinyEthTx} disabled={!ethWallet || evmBusy} className="px-4 py-2 rounded-xl border disabled:opacity-50 flex items-center gap-2 justify-center">
                {evmBusy ? <Loader2 className="w-4 h-4 animate-spin"/> : <Send className="w-4 h-4"/>} Send 0.0000001 BNB
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow p-5 mb-6">
          <div className="flex items-center gap-2 mb-3"><Coins className="w-5 h-5"/><h2 className="text-xl font-medium">EVM (MetaMask / ethers)</h2></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
            <div className="md:col-span-1 flex flex-col gap-2"></div>
            <div className="md:col-span-2 text-sm">
              <div><strong>Address:</strong> {ethWallet || '—'}</div>
              <div><strong>Balance:</strong> {ethBalance} BNB</div>
              <div><strong>Gas Price:</strong> {gasGwei} gwei</div>
              <div className="flex items-center gap-2"><strong>chainId (from RPC):</strong> {chainId ?? '—'} <span className="text-xs text-gray-500">(expected {EXPECTED_EVM_CHAIN_ID})</span></div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow p-5">
          <div className="flex items-center gap-2 mb-3"><Wallet className="w-5 h-5"/><h2 className="text-xl font-medium">Solana (Phantom / @solana/web3.js)</h2></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
            <div className="md:col-span-1 flex flex-col gap-2">
              <button onClick={connectPhantom} disabled={!solConn || solBusy} className="px-4 py-2 rounded-xl bg-emerald-600 text-white disabled:opacity-50 flex items-center gap-2 justify-center">
                {solBusy ? <Loader2 className="w-4 h-4 animate-spin"/> : <Wallet className="w-4 h-4"/>} Connect Phantom
              </button>
              <button onClick={solAirdrop} disabled={!solPubkey || solBusy} className="px-4 py-2 rounded-xl border disabled:opacity-50 flex items-center gap-2 justify-center">
                {solBusy ? <Loader2 className="w-4 h-4 animate-spin"/> : <Send className="w-4 h-4"/>} Faucet 0.01 (LAMPORTS)
              </button>
            </div>
            <div className="md:col-span-2 text-sm">
              <div><strong>Address:</strong> {solPubkey?.toBase58() || '—'}</div>
              <div><strong>Balance:</strong> {solBalance} SOL</div>
            </div>
          </div>
        </div>

        <div className="text-xs text-gray-500 mt-6 flex items-center gap-2">
          <ShieldCheck className="w-4 h-4"/> If your EVM RPC shows a different chainId, set VITE_EXPECTED_EVM_CHAIN_ID or adjust wallet network params.
        </div>
      </div>
    </div>
  );
}
